from selenium import webdriver
from client import LIClient
import argparse
import time


if __name__ == "__main__":

    # initialize selenium webdriver - pass latest chromedriver path to webdriver.Chrome()
    driver = webdriver.Chrome('/usr/local/bin/chromedriver')
    driver.maximize_window()
    driver.get("https://www.linkedin.com/uas/login")

    # initialize LinkedIn web client
    liclient = LIClient(driver, username='jan.kowali.69.69.69@gmail.com', password='aladarlinked1000')

    liclient.login()

    # wait for page load
    time.sleep(1)
    liclient.navigate_to_jobs_page()
    liclient.go_to_search_page()
    liclient.navigate_get_search_results()
    liclient.driver_quit()
