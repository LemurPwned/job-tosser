search_keys = { 
    "username"         :  "",
    "password"         :  "",
    # data is written to file in working directory as filename
    "filename"         :  "output.txt"
}
